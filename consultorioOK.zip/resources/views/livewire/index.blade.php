<div>
  {{ $patientsTotal }}
  {{ $appointmentsToday }}
  {{ $consultationsToday }}
  {{ $cashSaldoTotal }}
  {{ $sexStats }}

</div>
