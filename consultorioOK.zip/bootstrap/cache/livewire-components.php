<?php return array (
  'index' => 'App\\Http\\Livewire\\Index',
);