<div class="py-3">
    <hr />
</div>
<?php /**PATH C:\wamp64\www\consultorio\resources\views/vendor/jetstream/components/section-border.blade.php ENDPATH**/ ?>