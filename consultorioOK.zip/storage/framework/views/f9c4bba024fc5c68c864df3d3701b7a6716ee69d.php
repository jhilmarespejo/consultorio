<div>
  <?php echo e($patientsTotal); ?>

  <?php echo e($appointmentsToday); ?>

  <?php echo e($consultationsToday); ?>

  <?php echo e($cashSaldoTotal); ?>

  <?php echo e($sexStats); ?>


</div>
<?php /**PATH C:\wamp64\www\consultorio\resources\views/livewire/index.blade.php ENDPATH**/ ?>